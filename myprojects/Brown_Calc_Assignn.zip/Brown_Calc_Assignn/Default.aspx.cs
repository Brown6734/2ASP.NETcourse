﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;


namespace Brown_Calc_Assignn
{
    public partial class Default : System.Web.UI.Page
    {
        string strNum1;
        string strOperand;
        double result;

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void TextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        protected void btn1_Click(object sender, EventArgs e)
        {
            //concatenate a 1 here in the display
            txtLCD.Text += "1";
        }

        protected void btn2_Click(object sender, EventArgs e)
        {
            //concatenate a 2 here in the display
            txtLCD.Text += "2";
        }

        protected void btn3_Click(object sender, EventArgs e)
        {
            //concatenate a 3 here in the display
            txtLCD.Text += "3";
        }

        protected void btnNumeric_Click(object sender, EventArgs e)
        {
            //concatenate a number from the button's text property here in the display
            Button tempButton = (Button)sender;
            txtLCD.Text += tempButton.Text;
        }

        protected void btnPlus_Click(object sender, EventArgs e)
        {
            //store the value in the LCD
            Session["Num1"] = txtLCD.Text;

            //store the operand
            Session["Operand"] = "+";

            //clear the screen
            txtLCD.Text = "";


        }

        protected void btnEquals_Click(object sender, EventArgs e)
        {
            //txtLCD.Text = "";
            double Num2 = Double.Parse(txtLCD.Text);  //get the #s from txtbox and session
            double Num1 = Double.Parse(Session["Num1"].ToString());

            strOperand = Session["Operand"].ToString();   //store operand from session into local var

            if (strOperand == "+")    //perform appropriate math
            {
                result = Num1 + Num2;
            }

            txtLCD.Text = result.ToString();
            //output result

        }
    }
}